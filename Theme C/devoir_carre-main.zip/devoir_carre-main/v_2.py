def get_map_from_file(file_name : str) -> list:
    if len(file_name) < 5 or file_name[-4:] != ".map":
        print("Error : wrong file format pass")
        return None

    try:
        fo = open(file_name, "r")
    except Exception as error:
        print(error)
        return None

    my_map = []
    line = "start"
    while line:
        line = fo.readline()
        if len(line) > 0:
            my_map.append(line.strip("\n").split())
    fo.close()
    return my_map

a= get_map_from_file('file1.map')

def carre(a):
    carre_size = 0
    ponits_longueur = 0
    longueur_max = 0
    for y in range(len(a)):
        for x in range(len(a[0])):
            if a[y][x] == '.':
               ponits_longueur += 1
               count = 0
               for i in range(ponits_longueur):
                   try:
                    if a[y+i][x] == '.':
                           for j in range(ponits_longueur):
                               if a[y][x +i] == '.':
                                   count += 1

                   except IndexError:
                       None

               if count == ponits_longueur**2:
                   carre_size = ponits_longueur


            else:
                if longueur_max < ponits_longueur:
                    longueur_max = ponits_longueur
        ponits_longueur = 0
    return carre_size

print(carre(a))