import sys
import timeit

def get_map_from_file(file_name : str) -> list:
    if len(file_name) < 5 or file_name[-4:] != ".map":
        print("Error : wrong file format pass")
        return None

    try:
        fo = open(file_name, "r")
    except Exception as error:
        print(error)
        return None

    my_map = []
    line = "start"
    while line:
        line = fo.readline()
        if len(line) > 0:
            my_map.append(line.strip("\n").split())
    fo.close()
    return my_map

def find_carre(map : list):
    max_square_side = 0
    first_coordinate = ()
    for y in range(len(map)):
        for x in range(len(map[y])):
            if map[y][x] == ".":
                square_side = get_square_side(map, x, y)
                if square_side > max_square_side:
                    max_square_side = square_side
                    first_coordinate = (x, y)
    return first_coordinate, max_square_side

def print_solved_square(map : list, x : int, y : int, side : int) -> list:
    for i in range(side):
        for j in range(side):
            map[y + i][x + j] = "x"
    return map

def is_square_available(map : list, x : int, y : int, square_side : int) -> bool:
    size = (len(map[0]), len(map))
    valid = False
    validation_tab = []
    if x + square_side > size[0] or y + square_side > size[1]:
        return valid
    for i in range(square_side):
        for j in range(square_side):
            if map[y][x + j] == ".":
                if map[y + i][x + j] == ".":
                    validation_tab.append(True)
                else:
                    validation_tab.append(False)
            else:
                validation_tab.append(False)
    for k in validation_tab:
        if k == False:
            return False
    return True

def get_square_side(map : list, x : int, y : int) -> int:
    square_side = 2
    while is_square_available(map, x, y, square_side):
        square_side += 1
    return square_side - 1

def main(file) -> None:
    map = get_map_from_file(file)
    carre = find_carre(map)
    solved_map = print_solved_square(map, carre[0][0], carre[0][1], carre[1])
    for line in solved_map:
        print(" ".join(line))





