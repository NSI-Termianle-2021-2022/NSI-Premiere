import sys

from LPGCDM import *

main(sys.argv[1])
vgh